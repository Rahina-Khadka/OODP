package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PlayersReport extends JFrame {
	private String inputUsername;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlayersReport frame = new PlayersReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PlayersReport() {
		Connect();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 768, 498);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Score: ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(177, 115, 98, 49);
		contentPane.add(lblNewLabel);
		
		JLabel lblTotalCorrect = new JLabel("Total Correct: ");
		lblTotalCorrect.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblTotalCorrect.setBounds(165, 226, 211, 49);
		contentPane.add(lblTotalCorrect);
		
		JLabel dl = new JLabel("");
		dl.setFont(new Font("Tahoma", Font.PLAIN, 30));
		dl.setBounds(289, 22, 229, 49);
		contentPane.add(dl);
		
		JLabel scoretxt = new JLabel("");
		scoretxt.setFont(new Font("Tahoma", Font.PLAIN, 20));
		scoretxt.setBounds(285, 128, 55, 36);
		contentPane.add(scoretxt);
		
		JLabel correct1 = new JLabel("");
		correct1.setFont(new Font("Tahoma", Font.PLAIN, 27));
		correct1.setBounds(392, 239, 44, 36);
		contentPane.add(correct1);
		
		JButton playagain = new JButton("Play Again");
		playagain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserDashboard frame = new UserDashboard(inputUsername);
				frame.setVisible(true);
				PlayersReport.this.dispose();
			}
		});
		playagain.setFont(new Font("Tahoma", Font.PLAIN, 20));
		playagain.setBounds(289, 348, 137, 42);
		contentPane.add(playagain);
		
		JLabel correct1_1 = new JLabel("/");
		correct1_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		correct1_1.setBounds(432, 239, 21, 36);
		contentPane.add(correct1_1);
		
		JLabel correct2 = new JLabel("");
		correct2.setFont(new Font("Tahoma", Font.PLAIN, 27));
		correct2.setBounds(474, 239, 44, 36);
		contentPane.add(correct2);
		
		JLabel scoretxt_1 = new JLabel("%");
		scoretxt_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		scoretxt_1.setBounds(324, 128, 44, 36);
		contentPane.add(scoretxt_1);
		String sql = "SELECT username, score, correct_answer, total_questions, level FROM result ORDER BY id DESC LIMIT 1";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                inputUsername = rs.getString("username");
                int score = rs.getInt("score");
                int totalCorrect = rs.getInt("correct_answer");
                int totalQuestions= rs.getInt("total_questions");
                String level = rs.getString("level");
                //set the values to the text fields
                scoretxt.setText(String.valueOf(score)); 
                correct1.setText(String.valueOf(totalCorrect)); 
                correct2.setText(String.valueOf(totalQuestions)); 
                dl.setText(level); 
                
              
                
            } else {
                System.out.println("No entries found in the result table.");
            }
       
         
         }catch (Exception ex) {
            ex.printStackTrace();
        }
	}
	Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    public void Connect() {
    	
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
            System.out.println("Connection establish successfully!");
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }catch(SQLException ex) {
            ex.printStackTrace();

        }
    }

}
