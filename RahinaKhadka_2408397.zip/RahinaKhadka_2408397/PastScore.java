package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class PastScore extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField txtPastScore;
	private String inputUsername;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	 Connection conn;
		PreparedStatement pst;
	    ResultSet rs;
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					PastScore frame = new PastScore();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public PastScore(String inputUsername) {
		this.inputUsername= inputUsername;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 819, 539);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(98, 104, 488, 360);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserDashboard frame =new UserDashboard(inputUsername);
				frame.setVisible(true);
				PastScore.this.dispose();
			}
			
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 22));
		btnNewButton.setBounds(688, 429, 85, 35);
		contentPane.add(btnNewButton);
		
		txtPastScore = new JTextField();
		txtPastScore.setFont(new Font("Tahoma", Font.PLAIN, 25));
		txtPastScore.setText("Past Score");
		txtPastScore.setBounds(224, 33, 181, 57);
		contentPane.add(txtPastScore);
		txtPastScore.setColumns(10);
		
		tableLoad();
		}
	 public void tableLoad() {
	        
	        try {
	              Connect();
	              pst = conn.prepareStatement("SELECT id, username, correct_answer, total_questions, score, level FROM result WHERE username = ?",ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  pst.setString(1, inputUsername);
                  rs = pst.executeQuery();
	              table.setModel(DbUtils.resultSetToTableModel(rs));
	        }catch(Exception e) {
	            e.printStackTrace();
	        }
	    }
	
	    public void Connect() {
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
	            System.out.println("Connection establish successfully!");
	        }catch(ClassNotFoundException ex){
	            ex.printStackTrace();
	        }catch(SQLException ex) {
	            ex.printStackTrace();
	            
	        }
	    }

}
