package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AdminLogin extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usernametxt;
	private JPasswordField passwordtxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 897, 556);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		usernametxt = new JTextField();
		usernametxt.setBounds(392, 88, 141, 35);
		contentPane.add(usernametxt);
		usernametxt.setColumns(10);
		
		JLabel btnpassword = new JLabel("Password");
		btnpassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnpassword.setForeground(new Color(0, 0, 0));
		btnpassword.setBounds(240, 152, 105, 35);
		contentPane.add(btnpassword);
		
		JLabel btnusername = new JLabel("Username");
		btnusername.setBounds(240, 86, 105, 35);
		btnusername.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(btnusername);
		
		JButton btnlogin = new JButton("Login");
		btnlogin.setBackground(new Color(0, 255, 0));
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
			            // Establish a connection to the database
			            Connect();
			            String inputUsername, inputPassword, passdatabase=null;
			            int notfound=0;

			            // Check if the username field is empty
			            if (usernametxt.getText().trim().isEmpty()) {
			                JOptionPane.showMessageDialog(null, "Please enter a username", "Input Error", JOptionPane.ERROR_MESSAGE);
			                return; // Exit if the username is empty
			            } 
			            // Check if the password field is empty
			            if (passwordtxt.getText().trim().isEmpty()) {
			                JOptionPane.showMessageDialog(null, "Please enter a password", "Input Error", JOptionPane.ERROR_MESSAGE);
			                return; // Exit if the password is empty
			            }

			            // Get the username and password from the input fields
			            inputUsername = usernametxt.getText().trim();
			            inputPassword = passwordtxt.getText().trim();

			            // Prepare a statement to check for existing usernames
			            pst = conn.prepareStatement("SELECT * FROM authorized WHERE username = ?");
			            pst.setString(1, inputUsername);
			            rs = pst.executeQuery();

			            while (rs.next()) {
			            	passdatabase = rs.getString("password");
                            notfound = 1;
                        }

                        // Check if account exists already
                        if (notfound == 1 && inputPassword.equals(passdatabase)) {
                            if ("Rahina".equals(inputUsername)) {
                                JOptionPane.showMessageDialog(null, "Hello Admin!", "Success", JOptionPane.INFORMATION_MESSAGE);
                                HomePage frame = new HomePage();
                                frame.setVisible(true);
                               
                                AdminLogin.this.dispose();
                            } else {
                                JOptionPane.showMessageDialog(null, "Hello User!", "Success", JOptionPane.INFORMATION_MESSAGE);
                               //User Homepage logic
                                UserDashboard frame = new UserDashboard(inputUsername);
                                frame.setVisible(true);
                                
                                AdminLogin.this.dispose();
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Incorrect Username or Password", "Error", JOptionPane.ERROR_MESSAGE);
                        }

                        // Clear fields
                        usernametxt.setText("");
                        passwordtxt.setText("");
				 }
			         catch (Exception ex) {
			            ex.printStackTrace(); // Print the stack trace for debugging
			        }
			}
		});
		btnlogin.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnlogin.setBounds(317, 227, 85, 35);
		contentPane.add(btnlogin);
		
		passwordtxt = new JPasswordField();
		passwordtxt.setBounds(392, 154, 141, 35);
		contentPane.add(passwordtxt);
		
		JLabel btnadmin = new JLabel("Login");
		btnadmin.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnadmin.setBounds(346, 22, 92, 35);
		contentPane.add(btnadmin);
		
		JLabel lblAlreadyHaveAn = new JLabel("Already have an account?");
		lblAlreadyHaveAn.setForeground(Color.BLACK);
		lblAlreadyHaveAn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAlreadyHaveAn.setBounds(207, 309, 173, 35);
		contentPane.add(lblAlreadyHaveAn);
		
		JButton btnSignUp = new JButton("Sign up");
		btnSignUp.setBackground(new Color(0, 255, 0));
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SignupPage frame = new SignupPage();
                frame.setVisible(true);
                AdminLogin.this.dispose();
			}
		});
		btnSignUp.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnSignUp.setBounds(412, 308, 99, 35);
		contentPane.add(btnSignUp);
	}
	Connection conn;
	PreparedStatement pst;
    ResultSet rs;
    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
            System.out.println("Connection establish successfully!");
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }catch(SQLException ex) {
            ex.printStackTrace();
            
        }
    }
}
