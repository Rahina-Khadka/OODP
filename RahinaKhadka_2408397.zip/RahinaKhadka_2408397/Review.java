package coursework;

import javax.swing.JCheckBox;

public class Review {
	

	

	
	    public boolean isAnswerCorrect(JCheckBox btn1, JCheckBox btn2, 
	    		JCheckBox btn3, JCheckBox btn4, 
	                                    int correct) {
	        if (btn1.isSelected() && correct == 1) {
	            return true;
	        }
	        if (btn2.isSelected() && correct == 2) {
	            return true;
	        }
	        if (btn3.isSelected() && correct == 3) {
	            return true;
	        }
	        if (btn4.isSelected() && correct == 4) {
	            return true;
	        }
	        return false;
	    }
	}


