package coursework;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateConnection {
public static void main (String[] args)throws Exception{
	//Step 1 :Load Driver
	Class.forName("com.mysql.cj.jdbc.Driver");
	
	//Step2 :Connection Establish
	Connection  conn = DriverManager.getConnection("jdbc:mysql://localhost:3306",
	"root", "");
	System.out.println("Connection establish successfully!");
	
	String sql ="CREATE DATABASE Questions";
	
	//Step 3 :Create Statement
	Statement stmt = conn.createStatement();
	
	//Execute
	stmt.executeUpdate(sql);
	System.out.println("Database Created");
	
	conn.close();



}
}