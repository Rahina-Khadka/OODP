package coursework;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTable {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/questions";
        String user = "root";
        String password = "";
//
//        String sql = "CREATE TABLE IF NOT EXISTS Quiz_Information (" 
//                + "id INT AUTO_INCREMENT PRIMARY KEY, "
//                + "question VARCHAR(1000) NOT NULL, "
//                + "option1 VARCHAR(100) NOT NULL, "
//                + "option2 VARCHAR(100) NOT NULL, "
//                + "option3 VARCHAR(100) NOT NULL, "
//                + "option4 VARCHAR(100) NOT NULL, "
//                + "correct INT NOT NULL, "
//                + "level VARCHAR(100) NOT NULL"
//                + ")";
//        String sql = "CREATE TABLE IF NOT EXISTS Authorized("
//              + "id INT AUTO_INCREMENT PRIMARY KEY," 
//              + "username VARCHAR(127) NOT NULL,"
//              + "password VARCHAR(100) NOT NULL"
//              + ");";
        
//        String sql = "CREATE TABLE IF NOT EXISTS Result ("
//              + "id INT AUTO_INCREMENT PRIMARY KEY," 
//              + "username VARCHAR(127) NOT NULL,"
//              + "Correct_Answer INT NOT NULL,"
//              + "total_questions INT NOT NULL,"
//              + "score INT NOT NULL,"
//              + "level VARCHAR(100) NOT NULL"
//              + ");";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement()) {

//            System.out.println("Connection established successfully!");
//            
//            stmt.executeUpdate(sql);
//            System.out.println("Table 'Result' created successfully!");

        } catch (SQLException e) {
            e.printStackTrace(); 
        }
    }
}
