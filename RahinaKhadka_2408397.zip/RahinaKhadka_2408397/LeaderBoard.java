package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LeaderBoard extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTable table_2;

	/**
	 * Launch the application.
	 */
	 Connection conn ;
     PreparedStatement pst ;
     ResultSet rs ;
     ResultSet totalRs ;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LeaderBoard frame = new LeaderBoard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LeaderBoard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 893, 554);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane table1 = new JScrollPane();
		table1.setBounds(83, 172, 207, 335);
		contentPane.add(table1);
		
		table = new JTable();
		table1.setViewportView(table);
		table.setBackground(new Color(0, 255, 0));
		
		JScrollPane table2 = new JScrollPane();
		table2.setBounds(348, 172, 207, 335);
		contentPane.add(table2);
		
		table_1 = new JTable();
		table2.setViewportView(table_1);
		table_1.setBackground(new Color(255, 255, 0));
		
		JScrollPane table3 = new JScrollPane();
		table3.setBounds(597, 172, 207, 335);
		contentPane.add(table3);
		
		table_2 = new JTable();
		table3.setViewportView(table_2);
		table_2.setBackground(new Color(255, 0, 0));
		
		JLabel lblNewLabel = new JLabel("Intermediate");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel.setBounds(359, 132, 175, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Beginner");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(96, 132, 175, 30);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblAdvanced = new JLabel("Advanced");
		lblAdvanced.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblAdvanced.setBounds(615, 132, 175, 30);
		contentPane.add(lblAdvanced);
		
		JLabel lblNewLabel_2 = new JLabel("Leader Board");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_2.setBounds(253, 10, 239, 41);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Total Players");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblNewLabel_2_1.setBounds(21, 81, 137, 41);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel B1 = new JLabel("");
		B1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		B1.setBounds(197, 85, 53, 41);
		contentPane.add(B1);
		
		JLabel I1 = new JLabel("");
		I1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		I1.setBounds(373, 81, 53, 41);
		contentPane.add(I1);
		
		JLabel A1 = new JLabel("");
		A1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		A1.setBounds(635, 81, 53, 41);
		contentPane.add(A1);
		
		tableLoad("Beginner",table, B1);
		tableLoad("Intermediate",table_1, I1);
		tableLoad("Advanced",table_2, A1);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LeaderBoard.this.dispose();
			}
			
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 25));
		btnNewButton.setBounds(755, 7, 114, 62);
		contentPane.add(btnNewButton);
	}
	
    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
            System.out.println("Connection establish successfully!");
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }catch(SQLException ex) {
            ex.printStackTrace();
            
        }
    }
    public void tableLoad(String level, JTable table, JLabel totalLabel) {
       
        try {
            Connect();
            
            // Query to get the scores for the table
            pst = conn.prepareStatement("SELECT username, MAX(score) AS scores "
                    + "FROM result "
                    + "WHERE level = ? "
                    + "GROUP BY username "
                    + "ORDER BY scores DESC;",
                    ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            
            pst.setString(1, level);

            
            rs = pst.executeQuery();

            table.setModel(DbUtils.resultSetToTableModel(rs));

            pst = conn.prepareStatement("SELECT COUNT(DISTINCT username) AS total_players FROM result WHERE level = ?");
            pst.setString(1, level);
            totalRs = pst.executeQuery();

            if (totalRs.next()) { 
                int totalPlayers = totalRs.getInt("total_players");
                totalLabel.setText(String.valueOf(totalPlayers)); 
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        }
}
