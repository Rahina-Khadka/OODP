package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.Color;

public class HomePage extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage frame = new HomePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomePage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 824, 454);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnedit = new JButton("Edit");
		btnedit.setBackground(new Color(0, 255, 0));
		btnedit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 EditQuestion edit = new EditQuestion();
                 edit.setVisible(true);
                 HomePage.this.dispose();
			}
		});
		btnedit.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnedit.setBounds(272, 48, 230, 49);
		contentPane.add(btnedit);
		
		JButton btnview = new JButton("View");
		btnview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnview.setBackground(new Color(255, 128, 128));
		btnview.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnview.setBounds(97, 163, 253, 49);
		contentPane.add(btnview);
		
		JButton btnLeaderboard = new JButton("Leader Board");
		btnLeaderboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LeaderBoard frame = new LeaderBoard();
				frame.setVisible(true);
			}
		});
		btnLeaderboard.setBackground(new Color(255, 255, 128));
		btnLeaderboard.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnLeaderboard.setBounds(398, 229, 248, 49);
		contentPane.add(btnLeaderboard);
		
		JButton btnLogout = new JButton("Log Out");
		btnLogout.setBackground(new Color(255, 128, 0));
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminLogin frame = new AdminLogin();
                frame.setVisible(true);
                HomePage.this.dispose();
			}
		});
		btnLogout.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnLogout.setBounds(134, 319, 230, 49);
		contentPane.add(btnLogout);
	}

}
