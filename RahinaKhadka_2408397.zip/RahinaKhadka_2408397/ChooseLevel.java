package coursework;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class ChooseLevel extends JFrame {
	private String inputUsername;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ChooseLevel frame = new ChooseLevel();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public ChooseLevel(String inputUsername) {
		this.inputUsername=inputUsername;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 649, 471);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBeginner = new JButton("Beginner");
		btnBeginner.setBackground(new Color(0, 255, 0));
		btnBeginner.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				QuizGame frame = new QuizGame("Beginner", inputUsername);
                frame.setVisible(true);
                ChooseLevel.this.dispose();
			}
		});
		btnBeginner.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnBeginner.setBounds(194, 81, 205, 56);
		contentPane.add(btnBeginner);
		
		JButton btnAdvance = new JButton("Advanced");
		btnAdvance.setBackground(new Color(255, 0, 0));
		btnAdvance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				QuizGame frame = new QuizGame("Advanced", inputUsername);
                frame.setVisible(true);
                ChooseLevel.this.dispose();
			}
		});
		btnAdvance.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnAdvance.setBounds(194, 293, 205, 56);
		contentPane.add(btnAdvance);
		
		JButton btnIntermediate = new JButton("Intermediate");
		btnIntermediate.setBackground(new Color(255, 255, 0));
		btnIntermediate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				QuizGame frame = new QuizGame("Intermediate", inputUsername);
                frame.setVisible(true);
                ChooseLevel.this.dispose();
			}
		});
		btnIntermediate.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnIntermediate.setBounds(194, 189, 205, 56);
		contentPane.add(btnIntermediate);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserDashboard frame =new UserDashboard(inputUsername);
				frame.setVisible(true);
				ChooseLevel.this.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnBack.setBounds(476, 354, 134, 56);
		contentPane.add(btnBack);
	}

}
