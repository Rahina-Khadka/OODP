package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class SignupPage extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField passwordtxt;
	private JTextField usernametxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignupPage frame = new SignupPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignupPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 713, 521);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Sign Up");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel.setBounds(126, 33, 92, 21);
		contentPane.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Username");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPassword.setBounds(26, 87, 92, 21);
		contentPane.add(lblPassword);
		
		JLabel lblPassword_1 = new JLabel("Password");
		lblPassword_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPassword_1.setBounds(26, 139, 92, 21);
		contentPane.add(lblPassword_1);
		
		passwordtxt = new JTextField();
		passwordtxt.setBounds(126, 138, 143, 29);
		contentPane.add(passwordtxt);
		passwordtxt.setColumns(10);
		
		usernametxt = new JTextField();
		usernametxt.setColumns(10);
		usernametxt.setBounds(126, 91, 143, 29);
		contentPane.add(usernametxt);
		
		JLabel lblPassword_1_1 = new JLabel("Already have an account?");
		lblPassword_1_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPassword_1_1.setBounds(28, 293, 221, 29);
		contentPane.add(lblPassword_1_1);
		
		// Create a button for user registration
		JButton signupButton = new JButton("Create Account");

		// Add an action listener to the button
		signupButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent actionEvent) {
		        try {
		            // Establish a connection to the database
		            Connect();
		            String inputUsername, inputPassword;

		            // Check if the username field is empty
		            if (usernametxt.getText().trim().isEmpty()) {
		                JOptionPane.showMessageDialog(null, "Please enter a username", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return; // Exit if the username is empty
		            } 
		            // Check if the password field is empty
		            if (passwordtxt.getText().trim().isEmpty()) {
		                JOptionPane.showMessageDialog(null, "Please enter a password", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return; // Exit if the password is empty
		            }

		            // Get the username and password from the input fields
		            inputUsername = usernametxt.getText().trim();
		            inputPassword = passwordtxt.getText().trim();

		            // Prepare a statement to check for existing usernames
		            pst = conn.prepareStatement("SELECT * FROM authorized WHERE username = ?");
		            pst.setString(1, inputUsername);
		            rs = pst.executeQuery();

		            // If the username is found, display an error message
		            if (rs.next()) {
		                JOptionPane.showMessageDialog(null, "Username already exists. Please select a different one.", "Input Error", JOptionPane.ERROR_MESSAGE);
		            } else {
		                // If the username is not found, insert the new user into the database
		                pst = conn.prepareStatement("INSERT INTO authorized(username, password) VALUES (?, ?)");
		                pst.setString(1, inputUsername);
		                pst.setString(2, inputPassword);
		                pst.executeUpdate(); // Execute the insert operation

		                // Clear the input fields after successful registration
		                usernametxt.setText("");
		                passwordtxt.setText("");
		                // Notify the user of successful account creation
		                JOptionPane.showMessageDialog(null, "Your account has been created successfully!");
		                
		                // Open the Admin Login page
		                AdminLogin adminLoginFrame = new AdminLogin();
		                adminLoginFrame.setVisible(true);
		                adminLoginFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		                SignupPage.this.dispose(); // Close the registration frame
		            }
		        } catch (Exception e) {
		            e.printStackTrace(); // Print the stack trace for debugging
		        }
		    }
		});
		
		signupButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		signupButton.setBounds(71, 209, 169, 36);
		contentPane.add(signupButton);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminLogin frame = new AdminLogin();
                frame.setVisible(true);
                SignupPage.this.dispose();
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnLogin.setBounds(238, 286, 118, 36);
		contentPane.add(btnLogin);
		}
	Connection conn;
	PreparedStatement pst;
    ResultSet rs;
    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
            System.out.println("Connection establish successfully!");
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }catch(SQLException ex) {
            ex.printStackTrace();
            
        }
    }
}
