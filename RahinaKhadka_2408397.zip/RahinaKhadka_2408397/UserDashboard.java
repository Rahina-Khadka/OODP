package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class UserDashboard extends JFrame {
	private String inputUsername;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					UserDashboard frame = new UserDashboard();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public UserDashboard(String inputUsername) {
		this.inputUsername=inputUsername;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 639, 453);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnstart = new JButton("Start");
		btnstart.setBackground(new Color(0, 255, 0));
		btnstart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChooseLevel frame = new ChooseLevel(inputUsername);
				frame.setVisible(true);
				UserDashboard.this.dispose();
				
}
		});
		btnstart.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnstart.setBounds(222, 54, 150, 40);
		contentPane.add(btnstart);
		
		JButton btnpastscores = new JButton("Past Scores");
		btnpastscores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PastScore frame =new PastScore(inputUsername);
				frame.setVisible(true);
				UserDashboard.this.dispose();
			}
		});
		btnpastscores.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnpastscores.setBounds(63, 184, 197, 40);
		contentPane.add(btnpastscores);
		
		JButton btnLeaderboard = new JButton("LeaderBoard");
		btnLeaderboard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LeaderBoard frame = new LeaderBoard();
				frame.setVisible(true);
                
			}
		});
		btnLeaderboard.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnLeaderboard.setBounds(367, 184, 197, 40);
		contentPane.add(btnLeaderboard);
		
		JButton btnLogout = new JButton("Log Out");
		btnLogout.setBackground(new Color(255, 0, 0));
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminLogin frame = new AdminLogin();
                frame.setVisible(true);
                UserDashboard.this.dispose();
			}
		});
		btnLogout.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnLogout.setBounds(244, 293, 150, 40);
		contentPane.add(btnLogout);
	}

}
