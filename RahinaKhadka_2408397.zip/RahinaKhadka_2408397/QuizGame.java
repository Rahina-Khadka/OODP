package coursework;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.ButtonGroup;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class QuizGame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField Questiontext;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private int currentIndex =0;
	private List<QuestionList>questions;
	private String inputusername;
	private String level;
	private int total_correct=0;
	private int total_questions=0;
	private JCheckBox btn1;
	private JCheckBox btn2;
	private JCheckBox btn3;
	private JCheckBox btn4;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					QuizGame frame = new QuizGame();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public QuizGame(String level, String inputusername) {
        this.inputusername = inputusername;
        this.level = level;
        InsertQuestions(level);
        initializedUI();
        showQuestion(currentIndex);
    }
	public void initializedUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 516);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Questiontext = new JTextField();
		Questiontext.setBounds(92, 104, 521, 61);
		contentPane.add(Questiontext);
		Questiontext.setColumns(10);
		
		 btn1 = new JCheckBox("");
		buttonGroup.add(btn1);
		btn1.setBounds(108, 223, 149, 33);
		contentPane.add(btn1);
		
		 btn2 = new JCheckBox("");
		buttonGroup.add(btn2);
		btn2.setBounds(108, 283, 149, 33);
		contentPane.add(btn2);
		
		 btn3 = new JCheckBox("");
		buttonGroup.add(btn3);
		btn3.setBounds(342, 223, 149, 33);
		contentPane.add(btn3);
		
		 btn4 = new JCheckBox("");
		buttonGroup.add(btn4);
		btn4.setBounds(342, 283, 149, 33);
		contentPane.add(btn4);
		
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(btn1.isSelected()== true || btn2.isSelected()== true || btn3.isSelected()== true || btn4.isSelected()== true) {
                    Review checker = new Review();
                    QuestionList currentQuestion = questions.get(currentIndex);
                    boolean isCorrect = checker.isAnswerCorrect(btn1, btn2, 
                            btn3, btn4, 
                            currentQuestion.getCorrect());

                        if (isCorrect) {
                        	 JOptionPane.showMessageDialog(null, "You are correct", "Correct", JOptionPane.INFORMATION_MESSAGE);
                        
                        total_correct++;
                        } else {
                        	JOptionPane.showMessageDialog(null, "You are wrong", "Wrong", JOptionPane.INFORMATION_MESSAGE);
                            
                        }
                    total_questions++;
                    showNextQuestion();
                }else {
                    JOptionPane.showMessageDialog(null, "Select a option", "Error", JOptionPane.ERROR_MESSAGE);
                }
                 
            }
			
			
		});
		btnNext.setBackground(new Color(0, 255, 0));
		btnNext.setFont(new Font("Tahoma", Font.BOLD, 22));
		btnNext.setBounds(254, 364, 123, 61);
		contentPane.add(btnNext);
	}
	Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    public void Connect() {
    	
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
            System.out.println("Connection establish successfully!");
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }catch(SQLException ex) {
            ex.printStackTrace();

        }
    }
    public void CreateReport(){
        try {
            double score = ((double)total_correct/total_questions)*100;
            pst = conn.prepareStatement ("INSERT INTO result(username, Correct_Answer, total_questions, score, Level) values"+"(?,?,?,?,?)");
            pst.setString(1, inputusername);
            pst.setInt(2, total_correct);
            pst.setInt(3, total_questions);
            pst.setDouble(4, score);
            pst.setString(5, level);
            pst.executeUpdate();
       
         
         }catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    private void showQuestion(int index) {
        if (index < questions.size()) {
            QuestionList question = questions.get(index);
            Questiontext.setText(question.getQuestion());
            btn1.setText(question.getOption1());
            btn2.setText(question.getOption2());
            btn3.setText(question.getOption3());
            btn4.setText(question.getOption4());
            buttonGroup.clearSelection(); 
        } else {
            JOptionPane.showMessageDialog(this, "Quiz completed!");
            Connect();
            CreateReport();
            PlayersReport frame = new PlayersReport();
            frame.setVisible(true);
            frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            dispose();
        }
    }

    private void showNextQuestion() {
        currentIndex++;
        showQuestion(currentIndex);
    }

    // Inner class for Question
    public static class QuestionList {
        private String question;
        private String option1;
        private String option2;
        private String option3;
        private String option4;
        private int correct;

        public QuestionList( String question, String option1, String option2, String option3, String option4, int correct) {
            this.question = question;
            this.option1 = option1;
            this.option2 = option2;
            this.option3 = option3;
            this.option4 = option4;
            this.correct = correct;
        }

        public String getQuestion() { return question; }
        public String getOption1() { return option1; }
        public String getOption2() { return option2; }
        public String getOption3() { return option3; }
        public String getOption4() { return option4; }
        public int getCorrect() { return correct; }
    }
    void InsertQuestions(String level) {
        questions = new ArrayList<>();
        String query = "SELECT * FROM quiz_information WHERE level = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
             PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, level);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String questionText = rs.getString("question");
                String option1 = rs.getString("option1");
                String option2 = rs.getString("option2");
                String option3 = rs.getString("option3");
                String option4 = rs.getString("option4");
                int correct = rs.getInt("correct");

                questions.add(new QuestionList( questionText, option1, option2, option3, option4, correct));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }

        Collections.shuffle(questions); // Shuffle the questions
    }

}
