package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.ButtonGroup;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;

public class EditQuestion extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtopt1;
	private JTextField txtopt2;
	private JTextField txtopt3;
	private JTextField txtopt4;
	private JTextField Questiontext;
	private JTextField txtcorrect;

	/**
	 * Launch the application.
	 */
	Connection conn;
    PreparedStatement pst;
    ResultSet rs;
    private final ButtonGroup buttonGroup = new ButtonGroup();
    private JTextField txtsearch;
    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
            System.out.println("Connection establish successfully!");
        }catch(ClassNotFoundException ex){
            
        }catch(SQLException ex) {
            
        }
    }
    
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					EditQuestion frame = new EditQuestion();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public EditQuestion() {
		Connect();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 931, 571);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btndelete = new JButton("Delete");
		btndelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String search;
                search = txtsearch.getText();
                if (search.equals("")) {
                    JOptionPane.showMessageDialog(null, "Search an Id to delete!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                	Connect();
                	pst = conn.prepareStatement ("DELETE from quiz_information where id = ?");
                    pst.setString(1, search);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Data Deleted");
                    
                    Questiontext.setText(null);
                    txtopt1.setText(null);
                    txtopt2.setText(null);
                    txtopt3.setText(null);
                    txtopt4.setText(null);
                    txtcorrect.setText(null);
                    txtsearch.setText(null);
                    buttonGroup.clearSelection();
                    
                	
                }catch (Exception ex) {
                    ex.printStackTrace();
			}
			}
		});
		btndelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btndelete.setBounds(160, 487, 106, 37);
		contentPane.add(btndelete);
		
		JCheckBox L1 = new JCheckBox("Beginner");
		buttonGroup.add(L1);
		L1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		L1.setBounds(585, 184, 93, 21);
		contentPane.add(L1);
		
		JCheckBox L2 = new JCheckBox("Intermediate");
		buttonGroup.add(L2);
		L2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		L2.setBounds(585, 255, 130, 21);
		contentPane.add(L2);
		
		JCheckBox L3 = new JCheckBox("Advanced");
		buttonGroup.add(L3);
		L3.setFont(new Font("Tahoma", Font.PLAIN, 17));
		L3.setBounds(593, 319, 106, 21);
		contentPane.add(L3);
		
		JButton btnadd = new JButton("Add");
		btnadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connect();
				String question, option1, option2, option3, option4, correct;
				
				String level = null;
				question = Questiontext.getText();
				option1 = txtopt1.getText();
				option2 = txtopt2.getText();
				option3 = txtopt3.getText();
				option4 = txtopt4.getText();
				correct = txtcorrect.getText();
				
				if(L1.isSelected()== true) {
					level = "Beginner";
				}
				else if(L2.isSelected()== true) {
					level = "Intermediate";
				}
				else if(L3.isSelected()== true) {
					level = "Advanced";
				}
				else {
					JOptionPane.showMessageDialog(null, "Level not selected", "Error", JOptionPane.ERROR_MESSAGE);
				}
				 //Error Handling
				if (question.equals("") || option1.equals("") || option1.equals("") || option1.equals("") || option2.equals("") || option3.equals("") || option4.equals("") || correct.equals("")) {
                    JOptionPane.showMessageDialog(null, "All text fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

				try {
					pst = conn.prepareStatement ("INSERT INTO quiz_information(question, option1, option2, option3, option4, correct, level) values"+"(?,?,?,?,?,?,?)");
					pst.setString(1, question);
                    pst.setString(2, option1);
                    pst.setString(3, option2);
                    pst.setString(4, option3);
                    pst.setString(5, option4);
                    pst.setString(6, correct);
                    pst.setString(7, level);
                    pst.executeUpdate();
                  
	                  
                    JOptionPane.showMessageDialog(null, "Data added");
                   
                    Questiontext.setText(null);
                    txtopt1.setText(null);
                    txtopt2.setText(null);
                    txtopt3.setText(null);
                    txtopt4.setText(null);
                    txtcorrect.setText(null);
                    buttonGroup.clearSelection();
                 
				}catch (Exception ex) {
                    ex.printStackTrace();
                }
			}
		});
		
		btnadd.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnadd.setBounds(160, 420, 106, 37);
		contentPane.add(btnadd);
		
		JButton btnclear = new JButton("Clear");
		btnclear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Questiontext.setText(null);
                txtopt1.setText(null);
                txtopt2.setText(null);
                txtopt3.setText(null);
                txtopt4.setText(null);
                txtcorrect.setText(null);
                txtsearch.setText(null);
                buttonGroup.clearSelection();
			}
		});
		btnclear.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnclear.setBounds(338, 487, 106, 37);
		contentPane.add(btnclear);
		
		JButton btnupdate = new JButton("Update");
		btnupdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connect();
				String question, option1, option2, option3, option4, correct,search;
				
				String level = null;
				question = Questiontext.getText();
				option1 = txtopt1.getText();
				option2 = txtopt2.getText();
				option3 = txtopt3.getText();
				option4 = txtopt4.getText();
				correct = txtcorrect.getText();
				
				if(L1.isSelected()== true) {
					level = "Beginner";
				}
				else if(L2.isSelected()== true) {
					level = "Intermediate";
				}
				else if(L3.isSelected()== true) {
					level = "Advanced";
				}
				else {
					JOptionPane.showMessageDialog(null, "Level not selected", "Error", JOptionPane.ERROR_MESSAGE);
				}
				search=txtsearch.getText();
				
				 //Error Handling
				if (question.equals("") || option1.equals("") || option1.equals("") || option1.equals("") || option2.equals("") || option3.equals("") || option4.equals("") || correct.equals("")) {
                    JOptionPane.showMessageDialog(null, "All text fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
				if (search.equals("")) {
                    JOptionPane.showMessageDialog(null, "Search an Id to update!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

				try {
					pst = conn.prepareStatement ("UPDATE quiz_information set question = ?, option1 = ?, option2 = ?, option3 = ?, option4 = ?, correct = ?, level = ? where id = ?");
					pst.setString(1, question);
                    pst.setString(2, option1);
                    pst.setString(3, option2);
                    pst.setString(4, option3);
                    pst.setString(5, option4);
                    pst.setString(6, correct);
                    pst.setString(7, level);
                    pst.setString(8,search);
                    pst.executeUpdate();
                  
	                  
                    JOptionPane.showMessageDialog(null, "Data updated");
                   
                    Questiontext.setText(null);
                    txtopt1.setText(null);
                    txtopt2.setText(null);
                    txtopt3.setText(null);
                    txtopt4.setText(null);
                    txtcorrect.setText(null);
                    buttonGroup.clearSelection();
                 
				}catch (Exception ex) {
                    ex.printStackTrace();
                }
			}
		});
		btnupdate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnupdate.setBounds(338, 420, 106, 37);
		contentPane.add(btnupdate);
		
		txtopt1 = new JTextField();
		txtopt1.setBounds(122, 153, 96, 31);
		contentPane.add(txtopt1);
		txtopt1.setColumns(10);
		
		txtopt2 = new JTextField();
		txtopt2.setBounds(122, 211, 96, 32);
		contentPane.add(txtopt2);
		txtopt2.setColumns(10);
		
		txtopt3 = new JTextField();
		txtopt3.setBounds(380, 153, 96, 31);
		contentPane.add(txtopt3);
		txtopt3.setColumns(10);
		
		txtopt4 = new JTextField();
		txtopt4.setBounds(380, 210, 96, 33);
		contentPane.add(txtopt4);
		txtopt4.setColumns(10);
		
		Questiontext = new JTextField();
		Questiontext.setBounds(122, 99, 354, 31);
		contentPane.add(Questiontext);
		Questiontext.setColumns(10);
		
		txtcorrect = new JTextField();
		txtcorrect.setBounds(122, 269, 144, 34);
		contentPane.add(txtcorrect);
		txtcorrect.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Option 1");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(26, 147, 94, 37);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Option 2");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_1.setBounds(26, 207, 96, 37);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Option 3");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_2.setBounds(285, 147, 99, 37);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Option 4");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_3.setBounds(285, 205, 99, 37);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Question");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_4.setBounds(26, 93, 99, 37);
		contentPane.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Correct");
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_5.setBounds(26, 266, 99, 37);
		contentPane.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Level");
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_6.setBounds(603, 99, 83, 37);
		contentPane.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_4_1 = new JLabel("Edit Question");
		lblNewLabel_1_4_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel_1_4_1.setBounds(177, 29, 188, 37);
		contentPane.add(lblNewLabel_1_4_1);
		
		JLabel lblNewLabel_1_5_1 = new JLabel("Search");
		lblNewLabel_1_5_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_5_1.setBounds(26, 326, 99, 37);
		contentPane.add(lblNewLabel_1_5_1);
		
		txtsearch = new JTextField();
		txtsearch.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try {
					Connect();
					String id = txtsearch.getText();
                    pst = conn.prepareStatement ("SELECT question, option1, option2, option3, option4, correct, level from quiz_information where id = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();
                    
                    if(rs.next()== true) {
						String question = rs.getString(1);
						String option1 = rs.getString(2);
						String option2 = rs.getString(3);
						String option3 = rs.getString(4);
						String option4 = rs.getString(5);
						String correct = rs.getString(6);
						String level = rs.getString(7);
						
						Questiontext.setText(question);
		                txtopt1.setText(option1);
		                txtopt2.setText(option2);
		                txtopt3.setText(option3);
		                txtopt4.setText(option4);
		                txtcorrect.setText(correct);
		                
		                //case for level
		                switch (level) {
		                case "Beginner":
		                    L1.setSelected(true);
		                    break;
		                case "Intermediate":
		                    L2.setSelected(true);
		                    break;
		                case "Advanced":
		                    L3.setSelected(true);
		                    break;
		                }
	
					}else {
						Questiontext.setText(null);
		                txtopt1.setText(null);
		                txtopt2.setText(null);
		                txtopt3.setText(null);
		                txtopt4.setText(null);
		                txtcorrect.setText(null);
		                buttonGroup.clearSelection();
		                txtsearch.setText(null);
					}
					
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		txtsearch.setColumns(10);
		txtsearch.setBounds(122, 323, 144, 34);
		contentPane.add(txtsearch);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage frame =new HomePage();
				frame.setVisible(true);
				EditQuestion.this.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnBack.setBounds(593, 446, 106, 37);
		contentPane.add(btnBack);
		
		
	}
}
