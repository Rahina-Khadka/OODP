package coursework;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class FinalReport extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField searchtxt;
	

	/**
	 * Launch the application.
	 */
	
	Connection conn  ;
    PreparedStatement pst ;
    ResultSet rs ;
    
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FinalReport frame = new FinalReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FinalReport() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 831, 541);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage frame =new HomePage();
				frame.setVisible(true);
				FinalReport.this.dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 22));
		btnNewButton.setBounds(722, 439, 85, 35);
		contentPane.add(btnNewButton);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(131, 114, 488, 360);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		searchtxt = new JTextField();
		searchtxt.setBounds(260, 53, 359, 35);
		contentPane.add(searchtxt);
		searchtxt.setColumns(10);
		
		btnsearch = new JButton("Search");
		btnsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
                try {
                    Connect();
                    String username = searchtxt.getText(); 
                    pst = conn.prepareStatement("SELECT id, username, correct_answer, total_questions, score, level FROM result WHERE username = ?",ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                    pst.setString(1, username);
                    rs = pst.executeQuery();

                    if (!rs.next()) {
                        JOptionPane.showMessageDialog(null, "Username does not exist", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        rs.beforeFirst(); 
                        userInfoLoad(rs); 
                    }
            }catch(SQLException ex) {
                ex.printStackTrace();
            }
			}
		});
		btnsearch.setFont(new Font("Tahoma", Font.PLAIN, 22));
		btnsearch.setBounds(112, 43, 101, 44);
		contentPane.add(btnsearch);
		 tableLoad();
	}
	
    private JButton btnsearch;
    private JScrollPane scrollPane;
    public void Connect() {
    	
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/questions", "root", "");
            System.out.println("Connection establish successfully!");
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }catch(SQLException ex) {
            ex.printStackTrace();

        }
        
    }
   
    
    public void tableLoad() {
        
        try {
              Connect();
              pst = conn.prepareStatement("select * from result");
              rs = pst.executeQuery();
              table.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
    public void userInfoLoad(ResultSet rs) {
        try {
            table.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

}
